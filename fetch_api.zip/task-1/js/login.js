var sendbtn = document.getElementById('send-btn');
function send() {
    var mailId = document.getElementById("mail-btn").value;
    var pword = document.getElementById("pword-btn").value;
     var error1 = document.getElementById("error-msg-1");
     var error2 = document.getElementById("error-msg-2");

    if (mailId.length == 0) {
        error1.innerHTML = "Email id is required";
        error1.style.color = "red";

    }
    if (/(.+)@(.+){2,}\.(.+){2,}/.test(mailId)) {
        error1.innerHTML = "Success....";
        error1.style.color = "green";
    }
    if (pword.length == 0) {
        error2.innerHTML = "password is required";
        error2.style.color = "red";
    }
    if (pword.length < 6) {
        error2.innerHTML = "password more than character";
        error2.style.color = "red";
    }
    if (pword.length >= 6) 
    {
        error2.innerHTML = "success";
        error2.style.color = "green";
    }
}
sendbtn.addEventListener('click',send);
