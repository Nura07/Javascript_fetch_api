//------------------------------------------------all product
fetch('https://fakestoreapi.com/products/')
    .then((data) => {
        return data.json();
    })
    .then((completedata) => {
        // console.log(completedata[2].title);
        let item = "";
        completedata.map((value) => {
            item += ` <div class="card product-card" style='cursor:pointer'  id="single-btn" onclick="loadProperties('${value.id}')">
        <img class="img-fluid details mx-auto" src=${value.image} alt="Card image cap">
        <h4 class="category text-center">${value.category}</h4>
        <h6 class="price text-center">₹${value.price}</h6>
        </div>`
            // console.log(value);
        });
        document.getElementById('para-btn').innerHTML = item;
        // console.log(item);
    })
    .catch((err) => {
        console.log(err)
    })

//--------------------------------------------------get single product
//  var singlebtn = document.getElementById("single-btn");
//  console.log(singlebtn);
//  if(singlebtn)
//  {
//     singlebtn.addEventListener('click',open(id))

//  }

 function loadProperties(id)
 {
     
    let a= document.createElement("a");
    a.href='viewproduct.html?id='+id;
    a.target='_blank';
    document.body.appendChild(a);
    a.click();
    // document.body.removeChild(a);
 }


// ------------------------------------------------- all  category ---------------

var allbtn = document.getElementById('all-btn');
allbtn.addEventListener('click', function () {
    fetch('https://fakestoreapi.com/products')
        .then((data) => {
            return data.json();
        })
        .then((completedata) => {
            // console.log(completedata[2].title);
            let item = "";
            completedata.map((value) => {
                item += ` <div class="card product-card" onclick="loadProperties('${value.id}')">
                <h6>${value.id}</h6>
            <img class="img-fluid details" src=${value.image} alt="Card image cap" id="single-btn">
            <h4 class="category text-center">${value.category}</h4>
            <h6 class="price text-center">₹${value.price}</h6>
        

            </div>`
                // console.log(value);
            });
            document.getElementById('para-btn').innerHTML = item;
            // console.log(item);

        })
        .catch((err) => {
            console.log(err)
        })
});

//jewelery catagory
var jewelerybtn = document.getElementById('jewelery-btn')
jewelerybtn.addEventListener('click', function () {
    fetch('https://fakestoreapi.com/products/category/jewelery')
        .then((data) => {
            return data.json();
        })
        .then((completedata) => {
            // console.log(completedata[2].title);
            let item = "";
            completedata.map((value) => {
                item += ` <div class="card product-card" id="single-btn" onclick="loadProperties('${value.id}')">
                <h6>${value.id}</h6>
            <img class="img-fluid details" src=${value.image} alt="Card image cap">
            <h4 class="category text-center">${value.category}</h4>
            <h6 class="price text-center">₹${value.price}</h6>
        

            </div>`
                // console.log(value);
            });
            document.getElementById('para-btn').innerHTML = item;
            //  console.log(item);

        })
        .catch((err) => {
            console.log(err)
        })

})

//men category
var menbtn = document.getElementById('men-btn')
menbtn.addEventListener('click', function () {
    fetch("https://fakestoreapi.com/products/category/men's%20clothing")
        .then((data) => {
            return data.json();
        })
        .then((completedata) => {
            // console.log(completedata[2].title);
            let item = "";
            completedata.map((value) => {
                item += ` <div class="card product-card" id="single-btn" onclick="loadProperties('${value.id}')">
                <h6>${value.id}</h6>
            <img class="img-fluid details" src=${value.image} alt="Card image cap">
            <h4 class="category text-center">${value.category}</h4>
            <h6 class="price text-center">₹${value.price}</h6>
        

            </div>`
                // console.log(value);
            });
            document.getElementById('para-btn').innerHTML = item;
            // console.log(item);

        })
        .catch((err) => {
            console.log(err)
        })
})

//women category
var womenbtn = document.getElementById('women-btn')
womenbtn.addEventListener('click', function () {
    fetch("https://fakestoreapi.com/products/category/women's%20clothing")
        .then((data) => {
            return data.json();
        })
        .then((completedata) => {
            // console.log(completedata[2].title);
            let item = "";
            completedata.map((value) => {
                item += ` <div class="card product-card" id="single-btn" onclick="loadProperties('${value.id}')">
                <h6>${value.id}</h6>
            <img class="img-fluid details" src=${value.image} alt="Card image cap">
            <h4 class="category text-center">${value.category}</h4>
            <h6 class="price text-center">₹${value.price}</h6>
            </div>`
                // console.log(value);
            });
            document.getElementById('para-btn').innerHTML = item;
            // console.log(item);

        })
        .catch((err) => {
            console.log(err)
        })
})
//electroic category
var elebtn = document.getElementById('ele-btn')
elebtn.addEventListener('click', function () {
    fetch("https://fakestoreapi.com/products/category/electronics")
        .then((data) => {
            return data.json();
        })
        .then((completedata) => {
            // console.log(completedata[2].title);
            let item = "";
            completedata.map((value) => {
                item += ` <div class="card product-card" id="single-btn" onclick="loadProperties('${value.id}')">
                <h6>${value.id}</h6>
            <img class="img-fluid details" src=${value.image} alt="Card image cap">
            <h4 class="category text-center">${value.category}</h4>
            <h6 class="price text-center">₹${value.price}</h6>
            </div>`
                // console.log(value);
            });
            document.getElementById('para-btn').innerHTML = item;
            // console.log(item);

        })
        .catch((err) => {
            console.log(err)
        })
})
